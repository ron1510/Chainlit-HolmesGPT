# Internal integration checklist

Every unchecked item is **TODO: Configure in internal environment**. Keep Open WebUI operational until acceptance succeeds.

- [ ] Deploy/confirm the approved HolmesGPT 0.43.0 image in its separate pod and review internal patches. Set HOLMES_ADAPTER=holmes043. Supply full HOLMES_URL, TLS CA and credentials; confirm POST method, request shape and SSE event fixtures against the running service. No internal URL has been guessed.
- [ ] Start fresh native chats when transitioning from mock context. Non-empty native history must begin with the backend's system message; validate resumed real histories against 0.43.0.
- [ ] Bring the existing Python integration and reuse its request/attachment logic through `HOLMES_ADAPTER`. Capture sanitized events, including errors and terminal history. Add fixtures and run the tests.
- [ ] Accept/document the native 0.43.0 final-answer streaming limitation, or supply genuine final-answer deltas through the backend extension in PROTOCOL.md. Verify multiple chunks arrive **before completion** through vLLM, Holmes, Route and browser. Do not simulate tokens.
- [ ] Confirm which public query/command fields may be displayed for Prometheus/Grafana tools; add only audited adapter mappings. Verify private reasoning never appears in UI/logs.
- [ ] Decide whether approval-required events, frontend tools or follow-up buttons are needed. Those need a separate UI/protocol extension; current adapter fails safely on approvals.
- [ ] Supply PostgreSQL URL, TLS trust, new schema and least-privilege runtime role. Initialize with a migration role. Never use or alter Open WebUI tables. Validate user ownership, metadata sizes, thread listing, feedback, restart/resume and backups.
- [ ] Configure real per-user authentication using AUTH_USERS_FILE with generated hashes, or the organization's SSO callback. Configure stable CHAINLIT_AUTH_SECRET, secret rotation, ingress login throttling and session policies. Validate two users cannot access each other's chats or attachments. Do not share the bootstrap account.
- [ ] Decide whether optional Redis PING diagnostics are useful. Supply Redis TLS/auth URL only if wanted. No Redis keys or SSE operations exist. The reserved prefix is separate; Redis is neither required nor a scaling solution.
- [ ] Specify the existing PVC name, access mode, scheduling constraints and capacity. Confirm both pods can mount it concurrently without changing Open WebUI's setup.
- [ ] Configure SHARED_DIR and HOLMES_DIR to the same underlying subdirectory, considering different mount paths. Verify Holmes' file tool can read a newly uploaded file. Explicitly enable prompt_paths only if the existing tool accepts this convention, otherwise adapt request construction.
- [ ] Configure SCC-compatible UID/group/fsGroup and directory ownership on mounted storage. Test an arbitrary non-root UID and Holmes read permissions. Image chmod does not fix PVC ownership. Prevent other tenants replacing upload directories.
- [ ] Set upload/count/context/frame/answer/concurrency/time limits and align `.chainlit/config.toml`, proxy body limits, ephemeral disk and PVC quotas. Add malware inspection only if required by your upload policy.
- [ ] Agree on file retention and cleanup with active-reader protection. Published files are never auto-deleted. Decide whether owner-authorized downloads after restart are needed (old upload widgets are not restored).
- [ ] Set namespace, internal registry immutable image digest, target architecture, base-image digest, pull secrets, Service/Route host and TLS policy. Validate HTTP/WebSocket upgrades, external LB timeouts, NetworkPolicy and trusted proxy headers.
- [ ] Transfer the built image or target-compatible wheelhouse through the approved process. Test with network egress denied; disable telemetry and omit Literal API keys. Scan pinned dependencies/base image.
- [ ] Validate readiness/liveness, SIGTERM/rollout, Stop, disconnect, reconnection, abrupt pod kill, partial answer behavior and upstream task cancellation. Closing HTTP may not stop already-started Holmes tools.
- [ ] Load-test with realistic tool-output/context sizes and concurrent users. Tune requests/limits; one replica only until a separate session-scaling design is validated. Recreate causes rollout downtime.
- [ ] Review JSON logs, correlation IDs, alerts for failures/latency/overflow/disk capacity, and sensitive-data retention. Review Holmes' own prompt logging separately.
- [ ] Perform side-by-side Open WebUI regression tests, including uploads, context continuation, tool progress, final answer correctness and pod restart. Switch user traffic only after acceptance; retain rollback to Open WebUI.
