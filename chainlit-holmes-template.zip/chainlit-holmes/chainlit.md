# Holmes investigation

Investigate using HolmesGPT and files on the shared volume. Development mode uses a mock backend.
Activity displays public tool events only. Interrupted answers are explicitly marked incomplete.
