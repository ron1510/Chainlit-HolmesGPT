import getpass
from backend.auth import hash_password

if __name__ == "__main__":
    print(hash_password(getpass.getpass("Password: ")))
