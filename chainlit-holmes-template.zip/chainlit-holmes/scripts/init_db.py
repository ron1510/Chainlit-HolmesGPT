"""Explicit, non-destructive schema initialization; never run automatically at startup."""
import asyncio
import os
from pathlib import Path
import asyncpg
from dotenv import load_dotenv
from backend.persistence import schema_name


async def main():
    load_dotenv()
    schema = schema_name(os.environ["DATABASE_SCHEMA"])
    url = os.environ["DATABASE_URL"].replace("postgresql+asyncpg://", "postgresql://", 1)
    conn = await asyncpg.connect(url)
    try:
        async with conn.transaction():
            await conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
            await conn.execute(f'SET LOCAL search_path TO "{schema}"')
            await conn.execute((Path(__file__).resolve().parents[1] / "sql/001_chainlit.sql").read_text())
    finally:
        await conn.close()
    print("Dedicated Chainlit schema initialized; existing tables/data were not altered.")


if __name__ == "__main__":
    asyncio.run(main())
