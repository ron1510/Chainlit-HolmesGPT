"""Cap the HTTP body before Chainlit's upload route reads the entire file."""
import logging
from starlette.exceptions import HTTPException
from starlette.responses import JSONResponse

log = logging.getLogger("template.upload")


class UploadLimit:
    def __init__(self, app, limit):
        self.app, self.limit = app, limit

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope["path"].endswith("/project/file"):
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers", []))
        try:
            declared = int(headers.get(b"content-length", b"0"))
        except ValueError:
            declared = self.limit + 1
        if declared > self.limit:
            log.warning("upload_http_body_rejected")
            return await JSONResponse({"detail": "Upload too large"}, 413)(scope, receive, send)
        size = 0
        async def limited_receive():
            nonlocal size
            message = await receive()
            size += len(message.get("body", b""))
            if size > self.limit:
                log.warning("upload_http_body_rejected")
                raise HTTPException(413, "Upload too large")
            return message
        return await self.app(scope, limited_receive, send)
