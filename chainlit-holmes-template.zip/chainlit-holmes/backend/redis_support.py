"""Optional startup connectivity diagnostic only. No keys, pub/sub or SSE traffic."""
import logging
from redis.asyncio import Redis

log = logging.getLogger("template.redis")


async def check_redis(url):
    if not url:
        log.info("redis_disabled")
        return False
    client = Redis.from_url(url, socket_connect_timeout=3, socket_timeout=3)
    try:
        await client.ping()
        log.info("redis_connectivity_ok no_keys_written")
        return True
    except Exception as exc:
        log.warning("redis_optional_connectivity_failed type=%s", type(exc).__name__)
        return False
    finally:
        await client.aclose()
