"""Only allowlisted public progress reaches the UI; raw AI events are ignored."""
import importlib
import json
from dataclasses import dataclass
from typing import Any


class ProtocolError(Exception):
    pass


@dataclass
class Event:
    kind: str
    text: str = ""
    history: list[dict] | None = None


def string(data, key):
    value = data.get(key, "")
    if not isinstance(value, str):
        raise ProtocolError("Invalid string field")
    return value


class Holmes043:
    incremental = False

    def __init__(self, query_fields=None):
        # Mapping of exact tool names to audited dot-separated query fields.
        self.query_fields = query_fields or {}
        if not isinstance(self.query_fields, dict):
            raise ValueError("PUBLIC_QUERY_FIELDS must be a JSON object")
        for paths in self.query_fields.values():
            if not isinstance(paths, list) or any(not isinstance(path, str) or any(
                    part in {"reasoning", "reasoning_content", "content", "data"} for part in path.split(".")) for path in paths):
                raise ValueError("Query fields must be audited paths, never raw model/result data")

    def request(self, prompt, history, attachments, settings):
        if not isinstance(history, list) or any(not isinstance(item, dict) for item in history):
            raise ProtocolError("Invalid conversation history")
        if history and history[0].get("role") != "system":
            raise ProtocolError("HolmesGPT 0.43.0 history must begin with a system message; start a new chat")
        if attachments:
            if settings.attachment_mode != "prompt_paths":
                raise ProtocolError("Attachment request mapping has not been configured")
            # Explicit opt-in: this is a prompt convention, not a Holmes attachment API.
            prompt += "\n\nUser-uploaded files available to the file-reading tool:\n" + json.dumps(
                [a["holmes_path"] for a in attachments])
        return {"ask": prompt, "conversation_history": history, "stream": True}

    def decode(self, name, data):
        if name == "error":
            raise ProtocolError("Backend reported an error")
        if name == "approval_required":
            raise ProtocolError("Backend requires approval; approval UI is not configured")
        if name in {"start_tool_calling", "tool_calling_result"}:
            tool = string(data, "tool_name")[:150]
            text = f"{'Running' if name == 'start_tool_calling' else 'Completed'} tool: {tool}"
            for path in self.query_fields.get(tool, []):
                value = data
                for part in path.split("."):
                    value = value.get(part) if isinstance(value, dict) else None
                if isinstance(value, str):
                    text += "\n" + value[:1000]
            return Event("progress", text[:2000])
        if name == "conversation_history_compaction_start":
            return Event("progress", "Backend is compacting conversation history")
        if name == "conversation_history_compacted":
            return Event("progress", "Backend compacted conversation history")
        if name == "ai_answer_end":
            history = data.get("conversation_history")
            if not isinstance(history, list) or any(not isinstance(x, dict) for x in history):
                raise ProtocolError("Invalid conversation history")
            return Event("done", string(data, "analysis"), history)
        # ai_message includes reasoning and tool-planning text. Never render it.
        return None


class MockProtocol(Holmes043):
    incremental = True

    def request(self, prompt, history, attachments, settings):
        return {"ask": prompt, "conversation_history": history, "attachments": attachments}

    def decode(self, name, data):
        if name == "answer_delta":
            return Event("delta", string(data, "text"))
        if name == "public_progress":
            # Mock contract: public operational text only, never model reasoning.
            return Event("progress", string(data, "text")[:1000])
        return super().decode(name, data)


def load_adapter(name, settings=None):
    if name == "mock":
        return MockProtocol()
    if name == "holmes043":
        return Holmes043(json.loads(settings.public_query_fields) if settings else None)
    module, separator, cls = name.partition(":")
    if not separator:
        raise ValueError("Adapter must be mock, holmes043 or trusted.module:Class")
    return getattr(importlib.import_module(module), cls)()
