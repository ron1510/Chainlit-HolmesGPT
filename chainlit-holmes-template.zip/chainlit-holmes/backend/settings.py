import os
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


@dataclass(frozen=True)
class Settings:
    mode: str = "development"
    endpoint: str = "http://127.0.0.1:8090/investigate"
    adapter: str = "mock"
    token: str = ""
    ca_file: str = ""
    public_query_fields: str = "{}"
    shared_dir: Path = Path("./local-shared")
    holmes_dir: str = "/mock-shared"
    attachment_mode: str = "disabled"
    max_file_bytes: int = 20 * 1024 * 1024
    max_files: int = 5
    max_event_bytes: int = 2 * 1024 * 1024
    max_answer_chars: int = 200_000
    max_history_bytes: int = 1024 * 1024
    max_uploads: int = 100
    idle_timeout: float = 90
    total_timeout: float = 600
    ui_timeout: float = 10
    progress_interval: float = .3
    answer_queue_size: int = 128
    max_active: int = 20
    database_url: str = ""
    database_schema: str = ""
    redis_url: str = ""
    redis_prefix: str = "chainlit-holmes:"
    auth_mode: str = "none"
    auth_user: str = ""
    auth_password: str = ""
    auth_users_file: str = ""

    @classmethod
    def from_env(cls):
        defaults = cls()
        values = {}
        aliases = {"endpoint": "HOLMES_URL", "adapter": "HOLMES_ADAPTER",
                   "token": "HOLMES_BEARER_TOKEN", "ca_file": "HOLMES_CA_FILE"}
        for name in cls.__dataclass_fields__:
            value = os.getenv(aliases.get(name, name.upper()))
            if value is not None:
                default = getattr(defaults, name)
                values[name] = type(default)(value)
        result = cls(**values)
        result.validate()
        return result

    def validate(self):
        if self.mode not in {"development", "production"}:
            raise ValueError("Invalid MODE")
        if self.auth_mode not in {"none", "password"}:
            raise ValueError("Invalid AUTH_MODE")
        if self.attachment_mode not in {"disabled", "prompt_paths"}:
            raise ValueError("Invalid ATTACHMENT_MODE")
        if not PurePosixPath(self.holmes_dir).is_absolute() or ".." in PurePosixPath(self.holmes_dir).parts:
            raise ValueError("HOLMES_DIR must be an absolute container path")
        for name in ("max_file_bytes", "max_files", "max_event_bytes", "max_answer_chars",
                     "max_history_bytes", "max_uploads", "idle_timeout", "total_timeout",
                     "ui_timeout", "progress_interval", "answer_queue_size", "max_active"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        if self.database_url and (not self.database_schema or self.auth_mode == "none"):
            raise ValueError("Persistence requires DATABASE_SCHEMA and authentication")
        if self.auth_mode == "password" and not ((self.auth_users_file or (self.auth_user and self.auth_password)) and os.getenv("CHAINLIT_AUTH_SECRET")):
            raise ValueError("Password auth requires AUTH_USERS_FILE or AUTH_USER/AUTH_PASSWORD, and CHAINLIT_AUTH_SECRET")
        if self.mode == "production":
            if self.auth_mode == "none" or self.adapter == "mock":
                raise ValueError("Production requires authentication and a non-mock adapter")
            if any("TODO" in value for value in (self.auth_user, self.auth_password, os.getenv("CHAINLIT_AUTH_SECRET", ""))):
                raise ValueError("Replace authentication placeholders before production")
            for name in ("HOLMES_URL", "SHARED_DIR", "HOLMES_DIR"):
                if not os.getenv(name) or "TODO" in os.environ[name]:
                    raise ValueError(f"TODO: Configure in internal environment: {name}")
