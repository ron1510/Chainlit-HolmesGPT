import asyncio
import logging
import os
import re
import uuid
from pathlib import Path, PurePosixPath

log = logging.getLogger("template.attachments")


def safe_name(name):
    if not name or name in {".", ".."} or "/" in name or "\\" in name or "\x00" in name:
        raise ValueError("Invalid upload filename")
    name = re.sub(r"[^a-zA-Z0-9._-]", "_", name)[:120]
    if not name.strip("._"):
        raise ValueError("Invalid upload filename")
    return name


def copy_upload(source, name, settings):
    name = safe_name(name)
    root = settings.shared_dir.resolve(strict=True)
    # A fresh random directory plus exclusive create prevents cross-user collisions.
    folder = root / uuid.uuid4().hex
    folder.mkdir(mode=0o770)
    os.chmod(folder, 0o770)
    target = folder / name
    temporary = folder / ".uploading"
    total = 0
    try:
        if Path(source).is_symlink() or not Path(source).is_file():
            raise ValueError("Upload source must be a regular file")
        with open(source, "rb") as inp, open(temporary, "xb") as out:
            os.chmod(temporary, 0o660)
            while chunk := inp.read(64 * 1024):
                total += len(chunk)
                if total > settings.max_file_bytes:
                    raise ValueError("Upload exceeds size limit")
                out.write(chunk)
            out.flush()
            os.fsync(out.fileno())
        temporary.replace(target)
    except BaseException:
        temporary.unlink(missing_ok=True)
        folder.rmdir()
        raise
    log.info("upload_saved id=%s bytes=%d", folder.name, total)
    relative = target.relative_to(root).as_posix()
    return {"name": name, "relative_path": relative,
            "holmes_path": str(PurePosixPath(settings.holmes_dir) / relative), "bytes": total}


async def save_upload(source, name, settings):
    # Thread finishes atomic copy if cancelled; never delete a published Holmes file.
    return await asyncio.to_thread(copy_upload, source, name, settings)
