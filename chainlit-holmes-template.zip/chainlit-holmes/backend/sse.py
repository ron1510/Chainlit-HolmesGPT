import codecs
import json
import logging
import ssl
from contextlib import aclosing
import aiohttp
from .protocol import ProtocolError

log = logging.getLogger("template.sse")


async def frames(chunks, max_bytes):
    """Bounded UTF-8 SSE parser supporting LF, CRLF, CR, comments and multiline data."""
    decoder = codecs.getincrementaldecoder("utf-8-sig")("strict")
    line, data, event, size, after_cr = "", [], "message", 0, False
    async for chunk in chunks:
        for char in decoder.decode(chunk):
            if after_cr and char == "\n":
                after_cr = False
                continue
            after_cr = False
            size += len(char.encode("utf-8"))
            if size > max_bytes:
                raise ProtocolError("SSE event exceeds configured bound")
            if char not in "\r\n":
                line += char
                continue
            after_cr = char == "\r"
            if not line:
                if data:
                    yield event, "\n".join(data)
                data, event, size = [], "message", 0
            elif not line.startswith(":"):
                field, _, value = line.partition(":")
                if value.startswith(" "):
                    value = value[1:]
                if field == "data":
                    data.append(value)
                elif field == "event":
                    event = value
            line = ""
    decoder.decode(b"", final=True)
    # SSE dispatch requires a blank line. A partial EOF frame is never accepted.


class HolmesClient:
    def __init__(self, settings, adapter, session=None):
        self.settings, self.adapter = settings, adapter
        context = ssl.create_default_context(cafile=settings.ca_file or None)
        self.http = session or aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=None, connect=10, sock_read=settings.idle_timeout),
            connector=aiohttp.TCPConnector(ssl=context, limit=settings.max_active),
            trust_env=False, auto_decompress=False)

    async def close(self):
        await self.http.close()

    async def events(self, prompt, history, attachments):
        payload = self.adapter.request(prompt, history, attachments, self.settings)
        headers = {"Accept": "text/event-stream", "Accept-Encoding": "identity"}
        if self.settings.token:
            headers["Authorization"] = "Bearer " + self.settings.token
        async with self.http.post(self.settings.endpoint, json=payload, headers=headers, allow_redirects=False) as response:
            if response.status != 200:
                log.warning("holmes_http_error status=%d", response.status)
            response.raise_for_status()
            if response.status != 200:
                raise ProtocolError("Expected HTTP 200")
            if response.headers.get("content-type", "").split(";")[0].strip() != "text/event-stream":
                raise ProtocolError("Expected text/event-stream")
            async with aclosing(frames(response.content.iter_any(), self.settings.max_event_bytes)) as parsed:
                async for name, raw in parsed:
                    data = json.loads(raw)
                    if not isinstance(data, dict):
                        raise ProtocolError("SSE payload must be an object")
                    event = self.adapter.decode(name, data)
                    if event is not None:
                        if event.kind == "progress":
                            log.info("backend_progress_event")
                        yield event
                        if event.kind == "done":
                            return
            raise ProtocolError("Connection ended before completion")
