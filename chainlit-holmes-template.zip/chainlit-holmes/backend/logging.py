import json
import logging
import sys
from contextvars import ContextVar
from datetime import datetime, timezone

request_context = ContextVar("request_id", default=None)


class JsonFormatter(logging.Formatter):
    def format(self, record):
        # Never serialize arbitrary exception messages, request bodies or credentials.
        return json.dumps({"time": datetime.now(timezone.utc).isoformat(),
                           "level": record.levelname, "logger": record.name,
                           "event": record.getMessage(), "request_id": request_context.get()})


def configure():
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    logger = logging.getLogger("template")
    logger.handlers = [handler]
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
