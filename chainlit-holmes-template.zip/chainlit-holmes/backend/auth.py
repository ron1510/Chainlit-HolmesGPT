"""Optional local multi-user password hashes; production may replace with enterprise SSO."""
import hashlib
import hmac
import json
import secrets
from pathlib import Path


def hash_password(password):
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 600_000).hex()
    return f"pbkdf2_sha256$600000${salt}${digest}"


class PasswordUsers:
    def __init__(self, path):
        self.users = json.loads(Path(path).read_text())
        if not isinstance(self.users, dict) or not self.users:
            raise ValueError("AUTH_USERS_FILE must contain username-to-hash mappings")
        for encoded in self.users.values():
            algorithm, iterations, salt, digest = encoded.split("$")
            if algorithm != "pbkdf2_sha256" or iterations != "600000" or len(bytes.fromhex(salt)) != 16 or len(bytes.fromhex(digest)) != 32:
                raise ValueError("Invalid password hash configuration")
        self.dummy = next(iter(self.users.values()))

    def verify(self, username, password):
        encoded = self.users.get(username, self.dummy)
        _, iterations, salt, expected = encoded.split("$")
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(iterations)).hex()
        matched = hmac.compare_digest(expected, actual)
        return matched and username in self.users
