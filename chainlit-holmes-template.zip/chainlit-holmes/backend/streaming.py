import asyncio
import logging
import time
from collections import OrderedDict
from .protocol import ProtocolError

log = logging.getLogger("template.streaming")


async def stream_to_ui(events, ui, settings):
    """Progress is coalesced; answers never dropped. Overflow aborts instead of growing RAM."""
    answers = asyncio.Queue(settings.answer_queue_size)
    latest = [None]
    seen = OrderedDict()
    result = [None]
    total_chars = 0
    chunks = 0

    async def produce():
        try:
            await read_events()
        finally:
            # HTTP/anyio generators must close in the task that entered them.
            await events.aclose()

    async def read_events():
        async for event in events:
            if event.kind == "progress":
                if event.text not in seen:
                    seen[event.text] = True
                    if len(seen) > 256:
                        seen.popitem(last=False)
                    latest[0] = event.text
            else:
                try:
                    answers.put_nowait(event)
                except asyncio.QueueFull:
                    log.error("answer_queue_overflow capacity=%d", settings.answer_queue_size)
                    raise ProtocolError("Answer UI could not keep up") from None
                if event.kind == "done":
                    return
        raise ProtocolError("Missing completion event")

    async def consume():
        nonlocal total_chars, chunks
        while True:
            event = await answers.get()
            if event.kind == "delta":
                total_chars += len(event.text)
                if total_chars > settings.max_answer_chars:
                    raise ProtocolError("Answer exceeds configured bound")
                await asyncio.wait_for(ui.token(event.text), settings.ui_timeout)
                chunks += 1
            elif event.kind == "done":
                if not isinstance(event.history, list) or any(not isinstance(item, dict) for item in event.history):
                    raise ProtocolError("Completion lacks resumable history")
                if not chunks:
                    if len(event.text) > settings.max_answer_chars:
                        raise ProtocolError("Answer exceeds configured bound")
                    await asyncio.wait_for(ui.whole(event.text), settings.ui_timeout)
                    log.warning("answer_non_incremental")
                elif event.text and event.text != ui.content:
                    raise ProtocolError("Delta stream disagrees with final answer")
                result[0] = event.history
                log.info("answer_complete chunks=%d characters=%d", chunks, len(ui.content))
                return
            else:
                raise ProtocolError("Unsupported normalized event")

    async def progress():
        while True:
            await asyncio.sleep(settings.progress_interval)
            text, latest[0] = latest[0], None
            if text:
                await asyncio.wait_for(ui.progress(text), settings.ui_timeout)

    started = time.monotonic()
    tasks = [asyncio.create_task(produce()), asyncio.create_task(consume()), asyncio.create_task(progress())]
    producer, consumer, reporter = tasks
    try:
        async with asyncio.timeout(settings.total_timeout):
            # Observe failures from all tasks, including UI failures, immediately.
            pending = set(tasks)
            while not consumer.done():
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for task in done:
                    task.result()
            consumer.result()
        return result[0]
    except Exception as exc:
        log.error("stream_failed type=%s", type(exc).__name__)
        raise
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        log.info("stream_closed duration_ms=%d", (time.monotonic() - started) * 1000)
