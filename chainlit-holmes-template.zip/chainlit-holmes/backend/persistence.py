"""Chainlit's pinned SQL adapter, with isolated search_path and fail-loud SQL."""
import logging
import json
import asyncio
import weakref
import re
import time
from sqlalchemy import text
from chainlit.data.sql_alchemy import SQLAlchemyDataLayer

log = logging.getLogger("template.persistence")


def schema_name(value):
    if not re.fullmatch(r"[a-z][a-z0-9_]{0,62}", value) or value in {"public", "information_schema"} or value.startswith("pg_"):
        raise ValueError("Use a dedicated lowercase PostgreSQL schema")
    return value


class DataLayer(SQLAlchemyDataLayer):
    def __init__(self, url, schema):
        if not url.startswith("postgresql+asyncpg://"):
            raise ValueError("DATABASE_URL must use postgresql+asyncpg://")
        super().__init__(url, connect_args={"server_settings": {
            "search_path": schema_name(schema), "statement_timeout": "15000"}}, show_logger=False)
        self._thread_locks = weakref.WeakValueDictionary()

    async def update_thread(self, thread_id, name=None, user_id=None, metadata=None, tags=None):
        if metadata is not None:
            metadata = {k: v for k, v in metadata.items() if k not in {"holmes_history", "attachments"}}
        lock = self._thread_locks.setdefault(thread_id, asyncio.Lock())
        async with lock:
            await super().update_thread(thread_id, name, user_id, metadata, tags)

    async def save_context(self, thread_id, history, attachments):
        await self.update_thread(thread_id)
        await self.execute_sql('''INSERT INTO holmes_context ("threadId", history, attachments)
            VALUES (:id, :history, :attachments) ON CONFLICT ("threadId")
            DO UPDATE SET history=EXCLUDED.history, attachments=EXCLUDED.attachments''',
            {"id": thread_id, "history": json.dumps(history), "attachments": json.dumps(attachments)})

    async def load_context(self, thread_id):
        rows = await self.execute_sql('SELECT history, attachments FROM holmes_context WHERE "threadId"=:id', {"id": thread_id})
        return rows[0] if rows else {"history": [], "attachments": []}

    async def execute_sql(self, query, parameters):
        # The pinned upstream adapter has a text-LIKE favorites query, while our
        # metadata is JSONB. Cast only that expression; values remain parameterized.
        query = query.replace('s."metadata" LIKE :favorite_pattern', 'CAST(s."metadata" AS TEXT) LIKE :favorite_pattern')
        parameters = dict(parameters)
        if isinstance(parameters.get("modes"), dict):
            parameters["modes"] = json.dumps(parameters["modes"])
        started = time.monotonic()
        try:
            async with self.engine.begin() as connection:
                result = await connection.execute(text(query), parameters)
                if result.returns_rows:
                    return self.clean_result([dict(row._mapping) for row in result.fetchall()])
                return result.rowcount
        except Exception as exc:
            log.error("database_operation_failed type=%s", type(exc).__name__)
            raise RuntimeError("Conversation persistence failed") from None
        finally:
            if time.monotonic() - started > 1:
                log.warning("database_operation_slow duration_ms=%d", (time.monotonic() - started) * 1000)

    async def create_element(self, element):
        # File bytes stay on PVC. Durable references live in server-only holmes_context.
        # Do not upload blobs to SQL or silently copy files into a second blob store.
        log.info("attachment_element_skipped pvc_metadata_is_authoritative")

    async def check(self):
        await self.execute_sql("SELECT id FROM threads LIMIT 0", {})
        await self.execute_sql('SELECT "threadId" FROM holmes_context LIMIT 0', {})


def make_layer(settings):
    return DataLayer(settings.database_url, settings.database_schema) if settings.database_url else None
