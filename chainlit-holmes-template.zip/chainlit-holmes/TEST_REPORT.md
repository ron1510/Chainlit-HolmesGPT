# Validation report — 2026-10-12

## HolmesGPT 0.43.0 upgrade validation

The upgraded source passed **25 tests**, with **2 PostgreSQL-dependent tests skipped** and one upstream Traceloop/Pydantic deprecation warning. This run included real local Chainlit processes, WebSocket streaming, upload/follow-up behavior, cancellation/reconnect, and new native request/history/relay-error checks. `pip check` and Python compilation passed.

The exact upstream 0.43.0 server, request models, tool loop and SSE formatter were inspected. The native adapter is now `holmes043`; OpenShift configuration and documentation match. The request model requires system-first non-empty history, and the tool loop still uses `stream=False`. No live HolmesGPT 0.43.0 service was available; source inspection and synthetic protocol tests do not establish internal deployment compatibility.

Automatic approval review could not authorize starting the disposable PostgreSQL container because its review service hit a usage limit. The database tests were therefore not repeated for this upgrade. The Docker image was not rebuilt during the upgrade; rebuild from the updated source before deployment. The results below describe the earlier baseline checks, not new 0.43.0 container/database verification.

## Earlier baseline validation

`python -m pytest -q` with TEST_DATABASE_URL pointing to a disposable local PostgreSQL 16 container: **23 passed**, one upstream Traceloop/Pydantic deprecation warning. No internal service was contacted. Dependency verification: `pip check` passed. All Python sources compiled.

Tests cover:

* SSE parsing across byte boundaries, UTF-8, CRLF, comments, multiline data, frame limits and incomplete EOF.
* Native Holmes adapter field handling, complete-answer behavior, reasoning suppression, audited query mappings and attachment opt-in.
* Incremental chunks visible before completion; exact order/Markdown, progress deduplication, slow progress isolation, bounded answer backlog, total timeout and cancellation cleanup.
* Mock HTTP errors, content-type mismatch, backend error events and interrupted streams.
* Concurrent uploads, name/path rejection, actual byte-size enforcement, atomic shared-directory contents and collision prevention.
* Upload HTTP body limits with and without Content-Length.
* Optional Redis PING success/failure and disabled mode using mocks, including connection cleanup and no key writes.
* Thirty independent simulated streaming users; password-hash verification.
* Real PostgreSQL user/thread/step/feedback/list/favorites operations, dedicated schema enforcement and a fresh pool recovering context and attachment references.
* Real Chainlit 2.11.1 processes, actual WebSocket events, HTTP file upload, mock SSE over TCP, visible query progress, follow-up attachment reuse, Stop, interruption and socket disconnect/reconnect.
* Authenticated process termination/restart with persistent conversation context, stable login cookie, thread resumption and a second user denied access. Server logs are checked for asynchronous generator cleanup errors.

## Earlier baseline container checks

The Dockerfile built successfully on Linux/amd64 with the pinned dependency lock; `pip check` passed in the image. The tested Python base resolved to `python:3.12-slim@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1`. Pin your approved base digest for internal release builds.

The image started with `--network none --user 1001230000:0 --cap-drop ALL`. An in-container HTTP request to `/health/ready` returned `{"ready":true}`. `/app/.chainlit`, `/app/.files` and `/app/local-shared` were writable under that arbitrary UID. SIGTERM via `docker stop` produced `application_shutdown_complete` and exit code **0**.

## Not verified

* Your HolmesGPT pod, vLLM model, internal SSE customizations, file-reading tool or actual PVC mounts/permissions.
* Production token streaming: upstream 0.43.0 has no final-answer deltas on the inspected chat path. The mock supplies synthetic incremental chunks; it is not evidence of production model streaming.
* Internal PostgreSQL/Redis TLS, ACLs, schema grants, storage performance or restore procedures. Redis integration was mocked; a real Redis server was not needed for these checks.
* OpenShift admission/SCC, Route/WebSocket behavior, cluster network policy, production load sizing, shared PVC access mode or multi-pod scheduling.
* Browser visual rendering, enterprise SSO and any optional approval UI. WebSocket/API behavior was exercised directly.
* Tool cancellation inside Holmes after the frontend closes its HTTP request.

The Windows process-restart test verifies completed turn durability, not transactional recovery of an in-flight investigation. The Docker SIGTERM test verifies graceful idle shutdown; active cancellation is covered separately by Stop/disconnect tests. Follow INTEGRATION_TODO.md before switching traffic from Open WebUI.
