"""Opt-in real PostgreSQL test. Creates an isolated random schema; never existing tables."""
import os
import uuid
from pathlib import Path
import asyncpg
import pytest
from chainlit.user import User
from chainlit.context import init_http_context
from chainlit.message import Message
from chainlit.types import Pagination, ThreadFilter, Feedback
from backend.persistence import DataLayer


@pytest.mark.integration
async def test_real_postgres_restart():
    url = os.getenv("TEST_DATABASE_URL")
    if not url:
        pytest.skip("Set TEST_DATABASE_URL to a disposable PostgreSQL database")
    schema = "cl_test_" + uuid.uuid4().hex
    connection = await asyncpg.connect(url.replace("postgresql+asyncpg://", "postgresql://"))
    first = second = None
    try:
        await connection.execute(f'CREATE SCHEMA "{schema}"')
        await connection.execute(f'SET search_path TO "{schema}"')
        await connection.execute((Path(__file__).resolve().parents[1] / "sql/001_chainlit.sql").read_text())
        first = DataLayer(url, schema)
        await first.check()
        user = await first.create_user(User(identifier="test-user"))
        thread_id = str(uuid.uuid4())
        state = {"holmes_history": [{"role": "user", "content": "hi"}],
                 "attachments": [{"relative_path": "example/test.txt", "holmes_path": "/shared/example/test.txt"}]}
        await first.update_thread(thread_id, user_id=user.id, name="Test", metadata=state)
        await first.save_context(thread_id, state["holmes_history"], state["attachments"])
        init_http_context(thread_id=thread_id)
        message = Message(content="hello", modes={"test": "value"})
        await first.create_step(message.to_dict())
        await first.upsert_feedback(Feedback(forId=message.id, threadId=thread_id, value=1))
        await first.engine.dispose()
        second = DataLayer(url, schema)  # Fresh pool simulates app process restart.
        thread = await second.get_thread(thread_id)
        assert "holmes_history" not in thread["metadata"]
        assert "attachments" not in thread["metadata"]
        context = await second.load_context(thread_id)
        assert context["history"] == state["holmes_history"]
        assert context["attachments"] == state["attachments"]
        assert thread["steps"][0]["output"] == "hello"
        assert await second.get_thread_author(thread_id) == "test-user"
        assert (await second.get_user("test-user")).id == user.id
        listed = await second.list_threads(Pagination(first=10), ThreadFilter(userId=user.id))
        assert listed.data[0]["id"] == thread_id
        assert (await second.get_step(message.id))["feedback"]["value"] == 1
        assert await second.get_favorite_steps(user.id) == []
    finally:
        if first:
            await first.engine.dispose()
        if second:
            await second.engine.dispose()
        await connection.execute(f'DROP SCHEMA "{schema}" CASCADE')
        await connection.close()
