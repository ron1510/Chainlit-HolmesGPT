import asyncio
import json
from dataclasses import replace
from unittest.mock import AsyncMock, patch
import httpx
import aiohttp
from contextlib import asynccontextmanager
import pytest
from backend.attachments import save_upload
from backend.protocol import Event, Holmes043, MockProtocol, ProtocolError
from backend.redis_support import check_redis
from backend.settings import Settings
from backend.sse import HolmesClient, frames
from backend.streaming import stream_to_ui


class UI:
    def __init__(self):
        self.content = ""
        self.tokens = []
        self.progresses = []

    async def token(self, token):
        self.tokens.append(token)
        self.content += token

    async def whole(self, text):
        self.content = text

    async def progress(self, text):
        self.progresses.append(text)


async def chunks(*values):
    for value in values:
        yield value


async def test_sse_utf8_crlf_multiline_comments():
    wire = '\ufeff: keepalive\r\nevent: answer_delta\r\ndata: {"text":\r\ndata: "שלום"}\r\n\r\n'.encode()
    parsed = [x async for x in frames(chunks(*(bytes([b]) for b in wire)), 1000)]
    assert parsed == [("answer_delta", '{"text":\n"שלום"}')]


async def test_sse_bound_and_partial_eof():
    with pytest.raises(ProtocolError):
        _ = [x async for x in frames(chunks(b"data: " + b"x" * 100), 50)]
    assert [x async for x in frames(chunks(b"data: partial"), 100)] == []


def test_native_protocol_never_exposes_reasoning():
    adapter = Holmes043()
    assert not adapter.incremental
    assert adapter.decode("ai_message", {"reasoning": "private", "content": "planning"}) is None
    assert adapter.decode("start_tool_calling", {"tool_name": "prometheus", "reasoning": "private"}).text == "Running tool: prometheus"
    assert adapter.decode("ai_answer_end", {"analysis": "whole", "conversation_history": []}).kind == "done"
    with pytest.raises(ProtocolError):
        adapter.decode("approval_required", {})
    approved = Holmes043({"test_query_tool": ["description"]})
    assert "up{job" in approved.decode("tool_calling_result", {
        "tool_name": "test_query_tool", "description": 'up{job="demo"}', "reasoning": "private"}).text
    with pytest.raises(ValueError):
        Holmes043({"test": ["reasoning"]})


async def test_incremental_order_and_progress_dedup():
    ui = UI()
    gate = asyncio.Event()
    async def events():
        for _ in range(20):
            yield Event("progress", "Querying Prometheus")
        yield Event("delta", "**Hello")
        await asyncio.sleep(.03)
        assert ui.tokens == ["**Hello"]  # Visible before completion is generated.
        yield Event("delta", " world**")
        yield Event("done", "**Hello world**", [])
    assert await stream_to_ui(events(), ui, replace(Settings(), progress_interval=.005)) == []
    assert ui.tokens == ["**Hello", " world**"]
    assert ui.progresses == ["Querying Prometheus"]


async def test_whole_answer_is_not_fake_streamed():
    ui = UI()
    await stream_to_ui(chunks(Event("done", "whole", [])), ui, Settings())
    assert ui.content == "whole" and ui.tokens == []


async def test_slow_progress_does_not_block_ingestion():
    ui = UI()
    consumed = asyncio.Event()
    async def slow(text):
        await consumed.wait()
    ui.progress = slow
    async def events():
        yield Event("progress", "Working")
        await asyncio.sleep(.02)
        yield Event("delta", "x")
        consumed.set()
        yield Event("done", "x", [])
    await asyncio.wait_for(stream_to_ui(events(), ui, replace(Settings(), progress_interval=.001)), 1)
    assert consumed.is_set()


async def test_cancel_closes_source():
    closed = asyncio.Event()
    async def events():
        try:
            yield Event("delta", "partial")
            await asyncio.sleep(100)
        finally:
            closed.set()
    task = asyncio.create_task(stream_to_ui(events(), UI(), Settings()))
    await asyncio.sleep(.02)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert closed.is_set()


async def test_timeout_and_backlog_abort():
    async def stalled():
        await asyncio.sleep(1)
        yield Event("done", "", [])
    with pytest.raises(TimeoutError):
        await stream_to_ui(stalled(), UI(), replace(Settings(), total_timeout=.01))
    with pytest.raises(ProtocolError):
        await stream_to_ui(chunks(*(Event("delta", "x") for _ in range(100))), UI(), replace(Settings(), answer_queue_size=2))


@pytest.mark.parametrize("status,body,content_type", [
    (500, b"error", "text/plain"), (200, b"{}", "application/json"),
    (200, b"event: answer_delta\ndata: {\"text\":\"partial\"}\n\n", "text/event-stream"),
    (200, b"event: error\ndata: {}\n\n", "text/event-stream")])
async def test_http_errors(status, body, content_type):
    class Response:
        headers = {"content-type": content_type}
        def __init__(self):
            self.status = status
            self.content = self
        def raise_for_status(self):
            if status >= 400:
                raise aiohttp.ClientResponseError(None, (), status=status)
        def iter_any(self):
            return chunks(body)
    class Session:
        @asynccontextmanager
        async def post(self, *args, **kwargs):
            yield Response()
        async def close(self):
            pass
    client = HolmesClient(Settings(), MockProtocol(), Session())
    try:
        with pytest.raises((aiohttp.ClientError, ProtocolError)):
            _ = [e async for e in client.events("hi", [], [])]
    finally:
        await client.close()


async def test_concurrent_uploads_and_limits(tmp_path):
    shared = tmp_path / "shared"
    shared.mkdir()
    source = tmp_path / "source"
    source.write_bytes(b"abc")
    settings = replace(Settings(), shared_dir=shared)
    saved = await asyncio.gather(*(save_upload(source, "same.txt", settings) for _ in range(12)))
    assert len({x["holmes_path"] for x in saved}) == 12
    for item in saved:
        assert (shared / item["relative_path"]).read_bytes() == b"abc"
        assert item["holmes_path"].startswith("/mock-shared/")
    for name in ["../secret", "a/b", "a\\b", "..", "", "bad\x00"]:
        with pytest.raises(ValueError):
            await save_upload(source, name, settings)
    with pytest.raises(ValueError):
        await save_upload(source, "large", replace(settings, max_file_bytes=2))
    assert len(list(shared.iterdir())) == 12


async def test_optional_redis():
    assert not await check_redis("")
    mock = AsyncMock()
    with patch("backend.redis_support.Redis.from_url", return_value=mock):
        assert await check_redis("redis://local")
        mock.ping.assert_awaited_once()
        mock.aclose.assert_awaited_once()
        assert not mock.set.called
    mock.ping.side_effect = ConnectionError()
    with patch("backend.redis_support.Redis.from_url", return_value=mock):
        assert not await check_redis("redis://local")


async def test_concurrent_users_isolated():
    async def user(i):
        ui = UI()
        await stream_to_ui(chunks(Event("delta", str(i)), Event("done", str(i), [])), ui, Settings())
        return ui.content
    assert await asyncio.gather(*(user(i) for i in range(30))) == [str(i) for i in range(30)]


def test_attachment_opt_in():
    adapter = Holmes043()
    files = [{"holmes_path": "/shared/random/test.txt"}]
    with pytest.raises(ProtocolError):
        adapter.request("read", [], files, Settings())
    body = adapter.request("read", [], files, replace(Settings(), attachment_mode="prompt_paths"))
    assert "/shared/random/test.txt" in body["ask"]


def test_holmes043_request_preserves_native_history():
    from backend.protocol import load_adapter
    adapter = load_adapter("holmes043", Settings())
    history = [{"role": "system", "content": "backend system context"},
               {"role": "user", "content": "previous question"}]
    request = adapter.request("follow up", history, [], Settings())
    assert request == {"ask": "follow up", "conversation_history": history, "stream": True}
    assert request["conversation_history"] is history
    assert not adapter.incremental


@pytest.mark.parametrize("history", [[{"role": "user", "content": "mock history"}], ["invalid"]])
def test_holmes043_rejects_incompatible_history(history):
    with pytest.raises(ProtocolError):
        Holmes043().request("follow up", history, [], Settings())


def test_holmes043_relay_refusal_is_not_answer_content():
    with pytest.raises(ProtocolError, match="Backend reported an error"):
        Holmes043().decode("error", {"description": "private diagnostic", "error_code": 1,
                                    "msg": "private diagnostic", "success": False})


def test_schema_isolation():
    from backend.persistence import schema_name
    for schema in ["public", "pg_catalog", "a; DROP TABLE users", "", "Open-WebUI"]:
        with pytest.raises(ValueError):
            schema_name(schema)
    assert schema_name("chainlit_test") == "chainlit_test"


def test_password_users(tmp_path):
    from backend.auth import PasswordUsers, hash_password
    path = tmp_path / "users.json"
    path.write_text(json.dumps({"alice": hash_password("test-password")}))
    users = PasswordUsers(path)
    assert users.verify("alice", "test-password")
    assert not users.verify("alice", "wrong")
    assert not users.verify("bob", "test-password")


async def test_http_upload_limit_without_content_length():
    from backend.upload_limit import UploadLimit
    from starlette.applications import Starlette
    from starlette.responses import Response
    from starlette.routing import Route
    async def upload(request):
        await request.body()
        return Response("ok")
    app = UploadLimit(Starlette(routes=[Route("/project/file", upload, methods=["POST"])]), limit=8)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://test") as http:
        response = await http.post("/project/file", content=chunks(b"12345", b"67890"))
        assert response.status_code == 413
        assert (await http.post("/project/file", content=b"123456789")).status_code == 413
