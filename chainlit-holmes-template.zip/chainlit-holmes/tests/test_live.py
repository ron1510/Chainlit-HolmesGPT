"""Real HTTP + Socket.IO tests against spawned local processes and mock SSE."""
import asyncio
import os
import socket
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx
import pytest
import pytest_asyncio
import socketio


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


@pytest_asyncio.fixture
async def live_app(tmp_path):
    mock_port, ui_port = free_port(), free_port()
    env = dict(os.environ, MODE="development", AUTH_MODE="none", DATABASE_URL="", REDIS_URL="",
               HOLMES_ADAPTER="mock", HOLMES_URL=f"http://127.0.0.1:{mock_port}/investigate",
               SHARED_DIR=str(tmp_path / "shared"), HOLMES_DIR="/mock-shared")
    root = Path(__file__).resolve().parents[1]
    log = (tmp_path / "servers.log").open("w")
    processes = []
    try:
        for command in ([sys.executable, "-m", "uvicorn", "mock_server:app", "--host", "127.0.0.1", "--port", str(mock_port)],
                        [sys.executable, "-m", "chainlit", "run", "app.py", "--host", "127.0.0.1", "--port", str(ui_port), "--headless"]):
            processes.append(subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=log))
        url = f"http://127.0.0.1:{ui_port}"
        async with httpx.AsyncClient() as http:
            async with asyncio.timeout(30):
                while True:
                    try:
                        if (await http.get(url + "/health/ready")).status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                    await asyncio.sleep(.1)
        yield url, tmp_path / "shared"
    finally:
        for process in processes:
            process.terminate()
        for process in processes:
            try:
                await asyncio.to_thread(process.wait, 10)
            except subprocess.TimeoutExpired:
                process.kill()
                await asyncio.to_thread(process.wait)
        log.close()
        assert "Exception ignored in:" not in (tmp_path / "servers.log").read_text()


async def connect(url, headers=None, thread_id=None):
    client = socketio.AsyncClient()
    events = []
    async def record(name, *args):
        events.append((name, args[0] if args else None, time.monotonic()))
    client.on("*", record)
    sid = str(uuid.uuid4())
    await client.connect(url, socketio_path="ws/socket.io", transports=["websocket"], headers=dict(headers or {}),
                         auth={"sessionId": sid, "clientType": "webapp", "userEnv": "{}", "threadId": thread_id})
    await client.emit("connection_successful")
    await asyncio.sleep(.2)
    return client, sid, events


async def wait_event(events, predicate, timeout=8):
    async with asyncio.timeout(timeout):
        while not any(predicate(e) for e in events):
            await asyncio.sleep(.02)


async def send(client, text, references=None):
    await client.emit("client_message", {"message": {
        "id": str(uuid.uuid4()), "name": "User", "type": "user_message", "output": text,
        "createdAt": datetime.now(timezone.utc).isoformat(), "metadata": {}}, "fileReferences": references or []})


async def test_live_websocket_stream_and_upload(live_app):
    url, shared = live_app
    client, sid, events = await connect(url)
    try:
        async with httpx.AsyncClient() as http:
            assert (await http.get(url + "/health/live")).json() == {"status": "alive"}
            uploaded = await http.post(url + "/project/file", params={"session_id": sid}, files={"file": ("report.txt", b"mock data", "text/plain")})
            uploaded.raise_for_status()
        events.clear()
        await send(client, "Investigate upload", [uploaded.json()])
        await wait_event(events, lambda e: e[0] == "update_message" and e[1].get("output") == "Investigation completed")
        assert any(e[0] == "stream_start" for e in events)
        assert any(e[0] == "stream_token" for e in events)
        assert any(e[0] == "update_message" and "Prometheus query" in e[1].get("output", "") for e in events)
        complete = [e for e in events if e[0] == "update_message" and "Received 1 shared-volume" in e[1].get("output", "")]
        assert complete
        assert min(e[2] for e in events if e[0] == "stream_start") < complete[-1][2]
        assert next(shared.glob("*/report.txt")).read_bytes() == b"mock data"
        # Same session keeps attachment and conversation context for follow-ups.
        events.clear()
        await send(client, "Follow up")
        await wait_event(events, lambda e: e[0] == "update_message" and "Received 1 shared-volume" in e[1].get("output", ""))
    finally:
        await client.disconnect()


async def test_live_stop_disconnect_and_error(live_app):
    url, _ = live_app
    client, sid, events = await connect(url)
    try:
        await send(client, "/slow")
        await asyncio.sleep(.6)
        await client.emit("stop")
        await wait_event(events, lambda e: e[0] == "update_message" and "Interrupted" in e[1].get("output", ""))
        events.clear()
        await send(client, "/interrupt")
        await wait_event(events, lambda e: e[0] == "update_message" and "failed or was interrupted" in e[1].get("output", ""))
        events.clear()
        await send(client, "/slow")
        await asyncio.sleep(.6)
        await client.disconnect()
        # Reconnect the same session; old active work must have been cancelled.
        await client.connect(url, socketio_path="ws/socket.io", transports=["websocket"],
                             auth={"sessionId": sid, "clientType": "webapp", "userEnv": "{}"})
        await client.emit("connection_successful")
        events.clear()
        await send(client, "After reconnect")
        await wait_event(events, lambda e: e[0] == "update_message" and e[1].get("output") == "Investigation completed")
    finally:
        if client.connected:
            await client.disconnect()


@pytest.mark.integration
async def test_authenticated_process_restart_and_ownership(tmp_path):
    import asyncpg
    import json
    from backend.auth import hash_password
    url_pg = os.getenv("TEST_DATABASE_URL")
    if not url_pg:
        pytest.skip("Set TEST_DATABASE_URL to a disposable database")
    root = Path(__file__).resolve().parents[1]
    schema = "cl_test_" + uuid.uuid4().hex
    db = await asyncpg.connect(url_pg.replace("postgresql+asyncpg://", "postgresql://"))
    await db.execute(f'CREATE SCHEMA "{schema}"')
    await db.execute(f'SET search_path TO "{schema}"')
    await db.execute((root / "sql/001_chainlit.sql").read_text())
    users = tmp_path / "users.json"
    users.write_text(json.dumps({"alice": hash_password("alice-test"), "bob": hash_password("bob-test")}))
    mock_port, port = free_port(), free_port()
    url = f"http://127.0.0.1:{port}"
    env = dict(os.environ, MODE="development", AUTH_MODE="password", AUTH_USERS_FILE=str(users),
               CHAINLIT_AUTH_SECRET="local-test-secret-" + uuid.uuid4().hex,
               DATABASE_URL=url_pg, DATABASE_SCHEMA=schema, REDIS_URL="", HOLMES_ADAPTER="mock",
               HOLMES_URL=f"http://127.0.0.1:{mock_port}/investigate", SHARED_DIR=str(tmp_path / "shared"))
    processes, clients = [], []
    log = (tmp_path / "authenticated.log").open("w")
    def launch(command):
        process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=log)
        processes.append(process)
        return process
    async def start_ui():
        process = launch([sys.executable, "-m", "chainlit", "run", "app.py", "--host", "127.0.0.1", "--port", str(port), "--headless"])
        async with httpx.AsyncClient() as http:
            async with asyncio.timeout(30):
                while True:
                    try:
                        if (await http.get(url + "/health/ready")).status_code == 200:
                            return process
                    except httpx.HTTPError:
                        pass
                    await asyncio.sleep(.1)
    async def login(user):
        async with httpx.AsyncClient() as http:
            response = await http.post(url + "/login", data={"username": user, "password": user + "-test"})
            response.raise_for_status()
            return {"Cookie": "; ".join(f"{k}={v}" for k, v in http.cookies.items())}
    try:
        launch([sys.executable, "-m", "uvicorn", "mock_server:app", "--host", "127.0.0.1", "--port", str(mock_port)])
        first = await start_ui()
        alice = await login("alice")
        client, _, events = await connect(url, alice)
        clients.append(client)
        events.clear()
        await send(client, "Before restart")
        await wait_event(events, lambda e: e[0] == "update_message" and e[1].get("output") == "Investigation completed")
        thread_id = next(e[1]["thread_id"] for e in events if e[0] == "first_interaction")
        await client.disconnect()
        await asyncio.sleep(.2)
        assert await db.fetchval('SELECT jsonb_array_length(history) FROM holmes_context WHERE "threadId"=$1', thread_id) == 2
        first.terminate()
        await asyncio.to_thread(first.wait, 10)
        await start_ui()
        client, _, events = await connect(url, alice, thread_id)
        clients.append(client)
        await wait_event(events, lambda e: e[0] == "resume_thread")
        resumed = next(e[1] for e in events if e[0] == "resume_thread")
        assert "holmes_history" not in resumed["metadata"]
        assert any("Mock investigation" in s.get("output", "") for s in resumed["steps"])
        await send(client, "After restart")
        await wait_event(events, lambda e: e[0] == "update_message" and e[1].get("output") == "Investigation completed")
        assert await db.fetchval('SELECT jsonb_array_length(history) FROM holmes_context WHERE "threadId"=$1', thread_id) == 4
        bob = await login("bob")
        denied = socketio.AsyncClient()
        clients.append(denied)
        with pytest.raises(socketio.exceptions.ConnectionError):
            await denied.connect(url, socketio_path="ws/socket.io", transports=["websocket"], headers=bob,
                                 auth={"sessionId": str(uuid.uuid4()), "clientType": "webapp", "userEnv": "{}", "threadId": thread_id})
    finally:
        for client in clients:
            if client.connected:
                await client.disconnect()
        for process in processes:
            if process.poll() is None:
                process.terminate()
                await asyncio.to_thread(process.wait, 10)
        log.close()
        await db.execute(f'DROP SCHEMA "{schema}" CASCADE')
        await db.close()
        assert "Exception ignored in:" not in (tmp_path / "authenticated.log").read_text()
