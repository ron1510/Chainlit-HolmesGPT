# Verified protocol and extension contract

Inspection is against the upstream tags, not `main` or an assumed internal deployment:

* [HolmesGPT 0.43.0 server](https://github.com/HolmesGPT/holmesgpt/blob/0.43.0/server.py): POST `/api/chat`, request `ask`, `conversation_history`, `stream`.
* [0.43.0 models](https://github.com/HolmesGPT/holmesgpt/blob/0.43.0/holmes/core/models.py): request/response fields. No generic shared-PVC attachment request field is assumed.
* [0.43.0 tool loop](https://github.com/HolmesGPT/holmesgpt/blob/0.43.0/holmes/core/tool_calling_llm.py): `stream=False` at the model call; `START_TOOL` has `tool_name` and `id`. `AI_MESSAGE` may contain `reasoning`. `ANSWER_END` has the complete content.
* [0.43.0 SSE formatter](https://github.com/HolmesGPT/holmesgpt/blob/0.43.0/holmes/utils/stream.py): native event names and final mapping to `analysis` / `conversation_history`.
* [Chainlit 2.11.1 socket server](https://github.com/Chainlit/chainlit/blob/2.11.1/backend/chainlit/socket.py): disconnect invokes `on_chat_end`; stop cancels the current task.
* [Chainlit 2.11.1 server](https://github.com/Chainlit/chainlit/blob/2.11.1/backend/chainlit/server.py): startup/shutdown hooks and non-Redis Socket.IO initialization.
* [Chainlit 2.11.1 SQL adapter](https://github.com/Chainlit/chainlit/blob/2.11.1/backend/chainlit/data/sql_alchemy.py): pinned persistence interface.

No existing integration code was present in the provided workspace. When transferred internally, reuse its attachment request construction and any protocol adjustments inside a dedicated adapter.

The production selector is `HOLMES_ADAPTER=holmes043`; Chainlit remains pinned to 2.11.1. Holmes runs in its own pod, so it is not a Python dependency of this frontend. Update that pod's approved image separately during internal integration.

The 0.43.0 request model requires a non-empty `conversation_history` to start with a system message. The adapter validates this before dispatch and otherwise preserves the returned history unchanged. Start a new chat when switching from mock history to the native backend; do not fabricate a system message or reuse mock context. The formatter also represents relay refusals as native `error` events, which the adapter rejects without exposing raw backend error text.

## Native limitations

Native SSE supplies real tool starts, tool completions, and context-compaction events, but the final answer is not incremental. Intermediate `ai_message` is tool planning, not a reliable answer delta. We suppress the entire event and all reasoning fields. We do not split the final answer or reinterpret intermediate model output as final content.

The start event supplies a tool name, not a guaranteed Prometheus/Grafana query string. Tool results include `description` and structured `result`, but raw descriptions/results may contain sensitive information. Configure `PUBLIC_QUERY_FIELDS` as a JSON mapping of exact tool names to audited dot-separated field paths to display reported query strings. The default is `{}`; no query field is guessed. Paths containing reasoning/content/raw data fields are rejected. For a different wire shape use a custom adapter. Do not guess query text from tool names or display raw tool dumps.

If public progress is insufficient, a minimal backend extension should emit a documented public progress event with tool ID, status, tool name and approved query/command fields. Keep reasoning and raw result content out of that event.

## Genuine final-answer streaming

To meet token streaming in production, Holmes must request streaming from its LLM provider and relay actual `delta.content` chunks for a turn known to be the user-visible final answer. Never relay `reasoning_content`, tool-call arguments, or planning text. Determining that a turn is final is important: do not stream tool-planning turns and later reclassify them. A dedicated finalization phase without tools is one possible implementation. Preserve native tool orchestration, conversation history and terminal/error events.

The extension must flush deltas immediately through the server, route and vLLM path; setting `stream:true` on the HTTP request alone is insufficient. If the answer is returned whole, the template displays it once and logs `answer_non_incremental`. Validate received event timestamps and compare concatenated deltas byte-for-byte with the terminal answer. Do not claim a fixed one-token-per-event guarantee—providers may group multiple tokens into a chunk.

The mock's contract is intentionally explicit:

```text
event: public_progress
data: {"text":"Mock Prometheus query: up{job=\"demo\"}"}

event: answer_delta
data: {"text":"**Mock investigation**\n\n"}

event: ai_answer_end
data: {"analysis":"...exact concatenated answer...","conversation_history":[]}
```

Production custom adapter: set `HOLMES_ADAPTER=internal_adapter:Adapter`. Implement `incremental`, `request(prompt, history, attachments, settings)` and `decode(event_name, json_object) -> Event | None`. Normalized event kinds are `progress`, `delta`, `done`; backend errors raise `ProtocolError`. `done.history` must contain the backend's complete resumable history. Ignore unknown events; never use raw event JSON as UI content. Adapter modules are trusted deployment code, not user-uploaded plugins.

The native adapter rejects approval-required responses with a visible failed investigation. Approval controls, frontend tools and follow-up action buttons are not implemented; assess whether your existing integration requires them. Do not automatically approve tools to hide this limitation.
