"""Development protocol, deliberately not presented as the HolmesGPT wire format."""
import asyncio
import json
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

app = FastAPI()


def frame(event, data):
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


@app.post("/investigate")
async def investigate(request: Request):
    body = await request.json()
    prompt = body.get("ask", "")

    async def generate():
        yield frame("start_tool_calling", {"tool_name": "mock_prometheus", "id": "mock-1"})
        yield frame("public_progress", {"text": "Mock Prometheus query: up{job=\"demo\"}"})
        await asyncio.sleep(.4)
        if prompt == "/error":
            yield frame("error", {"description": "Injected mock error"})
            return
        if prompt == "/interrupt":
            yield frame("answer_delta", {"text": "Partial mock answer"})
            return
        if prompt == "/slow":
            await asyncio.sleep(120)
        yield frame("tool_calling_result", {"tool_name": "mock_prometheus", "tool_call_id": "mock-1"})
        # Chunks produced over time by this mock, not splitting a completed Holmes answer.
        chunks = ["**Mock investigation**\n\n", "The mock service ", "is healthy.\n\n",
                  f"Received {len(body.get('attachments', []))} shared-volume attachment reference(s)."]
        answer = ""
        for chunk in chunks:
            if await request.is_disconnected():
                return
            await asyncio.sleep(.15)
            answer += chunk
            yield frame("answer_delta", {"text": chunk})
        history = body.get("conversation_history", []) + [
            {"role": "user", "content": prompt}, {"role": "assistant", "content": answer}]
        yield frame("ai_answer_end", {"analysis": answer, "conversation_history": history})

    return StreamingResponse(generate(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
