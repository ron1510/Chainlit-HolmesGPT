# Chainlit 2.11.1 + HolmesGPT 0.43.0 template

A standalone frontend with asynchronous SSE, public investigation progress, shared-volume uploads, optional PostgreSQL history, and a local mock. No internal endpoints, credentials or existing Open WebUI tables are used. Open WebUI can remain deployed during validation.

For the internal 0.43.0 service, select `HOLMES_ADAPTER=holmes043` and configure its full endpoint. Local development remains `mock`. HolmesGPT runs separately and is not installed in this frontend image; deploy its approved 0.43.0 image independently and rebuild the frontend from this source. Start a new chat when moving from mock to native history.

**Compatibility finding:** upstream HolmesGPT **0.43.0 does not stream final-answer tokens** on its `/api/chat` SSE path. Its tool loop calls `completion(stream=False)` and the formatter emits the complete answer as `ai_answer_end.analysis`. The native adapter displays that answer once. It never fakes streaming. The mock emits timed deltas, exercising `Message.stream_token()` before completion. Genuine production token streaming requires an existing internally modified backend or the small protocol change described in [PROTOCOL.md](PROTOCOL.md).

## Run locally

Python 3.12 is the tested baseline. From this directory:

```sh
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# PowerShell: .venv/Scripts/Activate.ps1
python -m pip install -r requirements.lock
python -m pip install -r requirements-dev.txt
# Optional: copy .env.example to .env. Defaults already support local development.
python -m uvicorn mock_server:app --host 127.0.0.1 --port 8090
```

In a second terminal with the same environment:

```sh
chainlit run app.py --host 127.0.0.1 --port 8000 --headless
```

Open http://127.0.0.1:8000. Send a message, upload a file, then ask a follow-up. Mock commands: `/error`, `/interrupt`, `/slow` (use Stop or close the browser during `/slow`). Local mock mode needs no PostgreSQL, Redis, PVC, or model. Without PostgreSQL, history is memory-only and is lost at process restart.

Docker alternative:

```sh
mkdir -p local-shared
# On Linux, give the container UID/group access to this directory; e.g. group 0, mode 2770.
docker compose up --build
```

This mounts the same local directory into both containers at different paths. It does not provision or assume an internal PVC.

## Components

* `app.py`: Chainlit lifecycle, authentication, upload handling, resumption and UI.
* `backend/sse.py`: pooled async HTTP client, bounded UTF-8 SSE parser, TLS verification, status/content-type validation. No automatic retries or replay of investigations.
* `backend/protocol.py`: native versioned adapter, explicit mock contract and trusted `module:Class` extension point.
* `backend/streaming.py`: independent bounded answer queue and coalesced progress worker. Dedup cache holds at most 256 entries. Slow progress cannot block SSE reading; slow answer delivery aborts at the configured queue limit. Per-frame, answer, context, upload, active-user and wall-clock limits bound resource use.
* `backend/attachments.py`: chunked off-loop copying, exclusive random directories, safe names, actual byte limits, atomic rename, group-readable files. Never deletes published uploads.
* `backend/persistence.py`: official pinned SQLAlchemy adapter with a dedicated PostgreSQL search path and errors that propagate rather than silently losing history.

The frontend displays only allowlisted tool/stage progress. `ai_message` and `reasoning` are ignored. Raw tool results and model reasoning are never rendered as progress. The native adapter preserves the backend's opaque conversation history; it is sensitive database content even though it is not displayed.

## PostgreSQL and resumption

Set `DATABASE_URL=postgresql+asyncpg://...`, `DATABASE_SCHEMA` to a **new dedicated schema**, and authentication variables. URL-encode credentials. Configure verified TLS using the asyncpg URL options appropriate for your certificate trust (do not use the upstream adapter's `ssl_require=True`, which disables certificate verification).

```sh
python -m scripts.init_db
```

Initialization is explicit and transactional, creates only the named schema/tables/indexes, and never migrates or deletes Open WebUI data. Run with a migration role, then use a runtime role with only schema USAGE and table SELECT/INSERT/UPDATE/DELETE permissions. Existing incompatible tables are not automatically altered; use a fresh schema and review subsequent migrations. Back up this schema alongside the PVC.

Chainlit messages/steps/users/feedback live in those tables. Opaque Holmes history and attachment references live in a separate `holmes_context` table, never frontend-visible thread metadata. Context is saved on every completed turn, with attachment references saved before dispatch. `on_chat_resume` loads this server-side state after restart. A failed/in-flight turn is not added to successful Holmes context. Partial UI answers are marked interrupted; an abrupt SIGKILL can lose in-flight updates. Critical turn writes are awaited; Chainlit's own background persistence failures are logged.

Attachment bytes remain exclusively on the PVC. The template deliberately does not persist Chainlit attachment preview/download elements: after restart, uploaded files remain available to Holmes via metadata, but old upload preview/download widgets are not restored. This avoids an unauthenticated static PVC file server. Add an owner-authorized download endpoint only if needed internally.

## Authentication and Redis

Development defaults to no authentication. Production fails startup without authentication. The password callback supports either one bootstrap account (`AUTH_USER`/`AUTH_PASSWORD`) or a per-user hash file (`AUTH_USERS_FILE`). Generate a hash with `python -m scripts.hash_password`, then provision a secret-mounted JSON object mapping each username to its generated hash. Hashes use PBKDF2-SHA256, 600,000 iterations and random salts; checking runs off the event loop. Never commit passwords/hash files. Alternatively replace the callback with the organization's SSO hook. Do not share the bootstrap account among unrelated users: history ownership follows the login identifier. Use a strong, stable `CHAINLIT_AUTH_SECRET` across restarts. Configure perimeter login throttling and TLS internally.

Redis is **not required**. The inspected Chainlit 2.11.1 socket server constructs its AsyncServer without a Redis manager and keeps sessions locally. `REDIS_URL`, if present, enables one optional startup PING diagnostic, with bounded timeout and connection cleanup. No keys, locks, Pub/Sub, answer chunks, history or session state are written to Redis. `REDIS_PREFIX=chainlit-holmes:` is reserved for any future approved feature; currently zero keys means zero conflicts. Redis failure does not stop the UI. This diagnostic does not enable distributed sessions or horizontal scaling.

## Shared PVC

Set `SHARED_DIR` to Chainlit's attachment root and `HOLMES_DIR` to the **same physical directory** as seen in Holmes' container. The same relative UUID/name is appended to each root. Do not provide user-controlled filesystem roots. Only Chainlit should write this subdirectory; other users/pods must not be able to replace directories with symlinks. Files are 0660 and directories 0770; establish a shared allowed group/fsGroup on the PVC through cluster storage policy. Docker image permissions cannot fix permissions on a mounted PVC.

Native requests reject attachments by default. Once you confirm that the existing Holmes file-reading tool accepts paths in the user prompt, explicitly set `ATTACHMENT_MODE=prompt_paths`; otherwise implement `Adapter.request()` using the existing internal integration. No invented attachment field is sent to native Holmes. A file path is not a security boundary for Holmes tools: enforce their filesystem allowlist and tool permissions in Holmes itself.

No cleanup job is supplied because file lifetime and active readers are unknown. Establish retention, quotas, monitoring and a safe owner-aware cleanup policy internally. Align Chainlit `.chainlit/config.toml` upload size/count limits with application limits and ingress limits. An ASGI middleware caps each upload HTTP body at MAX_FILE_BYTES plus 64 KiB of multipart overhead, including chunked requests; the copy additionally enforces the exact file-byte limit. Chainlit still reads each accepted upload into memory, so size/concurrency limits and ingress controls matter.

## Deployment and air gap

Review `openshift/template.yaml` and `secret.example.yaml`; they intentionally contain non-deployable placeholders. Configure the existing PVC, internal registry, URL, per-user authentication, secrets, trusted certificates and networking. The deployment uses one replica and Recreate to avoid assuming RWX access or distributed sessions. Recreate introduces downtime during upgrades. Do not scale it based on Redis availability.

The image uses Python slim, no Holmes/model SDK, and arbitrary non-root UID-compatible group permissions. Chainlit itself brings a substantial transitive dependency tree; the lock records it. Runtime needs no downloads. Telemetry is disabled; do not set `LITERAL_API_KEY`. Build for the cluster architecture, scan and pin the base/image digests externally, then transfer:

```sh
docker build -t chainlit-holmes:2.11.1-template .
docker save -o chainlit-holmes.tar chainlit-holmes:2.11.1-template
# Transfer through approved process; inside the isolated environment:
docker load -i chainlit-holmes.tar
docker tag chainlit-holmes:2.11.1-template INTERNAL_REGISTRY/PROJECT/chainlit-holmes:TAG
docker push INTERNAL_REGISTRY/PROJECT/chainlit-holmes:TAG
```

Alternatively pre-download wheels for the target Linux architecture and use `pip --no-index --find-links` in an approved build. A Windows environment is not a Linux wheelhouse. The runtime image excludes tests and local secrets; dependency lock is version-pinned, not hash-verified or a vulnerability certification.

OpenShift Routes support the Chainlit WebSocket transport; validate the external load balancer too. Route timeout is 15 minutes versus the app's 10-minute investigation deadline. Keep TLS termination and forwarded-header trust restricted to your ingress. No extra WebSocket or messaging service is added.

`/health/live` checks the process/event loop, `/health/ready` reports successful initialization. Readiness does not continuously probe Holmes (avoids restart loops when Holmes is unavailable). Request failures report later upstream outages. SIGTERM uses Chainlit's app-shutdown hook to cancel tasks, close streams/pools and stop cleanly; Stop and socket disconnect also cancel active work. Closing the HTTP stream does not guarantee Holmes stops already-running tools—validate its server-side cancellation separately.

## Logs and tests

Template logs are JSON at INFO/WARNING/ERROR for startup, auth outcome, upload bytes/opaque ID, request correlation, completion/chunk counts, cancellation, queue/transport/UI failures, database failure/latency and optional Redis checks. Prompts, credentials, raw events, tool output, file contents and full exception strings are not logged. Chainlit has its own framework logs; review your log sink and retention. Native Holmes upstream logs may contain prompts; its policy must be reviewed separately.

```sh
python -m pytest -q
# Optional isolated PostgreSQL test; creates and drops only a random cl_test_* schema:
# Set TEST_DATABASE_URL=postgresql+asyncpg://... to a disposable database, then:
python -m pytest -q -m integration
```

See [TEST_REPORT.md](TEST_REPORT.md) for checks actually executed and [INTEGRATION_TODO.md](INTEGRATION_TODO.md) for internal acceptance gates. Mock and local tests do not establish compatibility with your running Holmes service, vLLM, route, SCC or PVC.

For optional local database/Redis services, set `LOCAL_POSTGRES_PASSWORD` to a local-only password and run `docker compose -f compose.infra.yaml up -d`. The services bind only to loopback at ports 55432 and 56379. Use the `chainlit_test` database/user in TEST_DATABASE_URL, URL-encoding your test password. These are disposable local services, not replacements for existing cluster services. Stop them with `docker compose -f compose.infra.yaml down`; the named PostgreSQL volume remains for restart testing.
