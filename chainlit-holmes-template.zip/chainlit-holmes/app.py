import asyncio
import hmac
import json
import logging
import uuid

import chainlit as cl
from dotenv import load_dotenv
from backend.attachments import save_upload
from backend.auth import PasswordUsers
from backend.logging import configure, request_context
from backend.persistence import make_layer
from backend.protocol import load_adapter
from backend.redis_support import check_redis
from backend.settings import Settings
from backend.sse import HolmesClient
from backend.streaming import stream_to_ui

load_dotenv()
configure()
log = logging.getLogger("template.app")
settings = Settings.from_env()
adapter = load_adapter(settings.adapter, settings)
layer = make_layer(settings)
client = None
active = {}  # Kept outside persisted user_session; tasks must not be serialized.
ready = False

if layer:
    @cl.data_layer
    def get_layer():
        return layer

if settings.auth_mode == "password":
    password_users = PasswordUsers(settings.auth_users_file) if settings.auth_users_file else None
    @cl.password_auth_callback
    async def authenticate(username, password):
        if password_users:
            valid = await asyncio.to_thread(password_users.verify, username, password)
        else:
            valid_user = hmac.compare_digest(username.encode(), settings.auth_user.encode())
            valid_password = hmac.compare_digest(password.encode(), settings.auth_password.encode())
            valid = valid_user and valid_password
        log.info("authentication_result success=%s", valid)
        if valid:
            return cl.User(identifier=username, metadata={"provider": "password"})
        return None


@cl.on_app_startup
async def startup():
    global client, ready
    await asyncio.to_thread(settings.shared_dir.mkdir, parents=True, exist_ok=True)
    def check_storage():
        probe = settings.shared_dir / (".probe-" + uuid.uuid4().hex)
        with probe.open("xb") as handle:
            handle.write(b"ok")
        probe.unlink()
    await asyncio.to_thread(check_storage)
    if layer:
        await layer.check()
    await check_redis(settings.redis_url)
    client = HolmesClient(settings, adapter)
    ready = True
    log.info("application_ready adapter=%s persistence=%s max_active=%d", settings.adapter, bool(layer), settings.max_active)
    if not adapter.incremental:
        log.warning("backend_has_no_verified_answer_deltas")


@cl.on_app_shutdown
async def shutdown():
    global ready
    ready = False
    tasks = list(active.values())
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    if client:
        await client.close()
    if layer:
        await layer.engine.dispose()
    log.info("application_shutdown_complete")


# These routes precede the SPA catch-all: Chainlit imports this file during setup.
from chainlit.server import app as server
from fastapi.responses import JSONResponse
from backend.upload_limit import UploadLimit

server.add_middleware(UploadLimit, limit=settings.max_file_bytes + 65536)


async def live():
    return {"status": "alive"}


async def readiness():
    return JSONResponse({"ready": ready}, status_code=200 if ready else 503)


# Insert ahead of the existing frontend catch-all, without replacing Chainlit lifecycle.
from fastapi.routing import APIRoute
server.router.routes.insert(0, APIRoute("/health/live", live, methods=["GET"]))
server.router.routes.insert(0, APIRoute("/health/ready", readiness, methods=["GET"]))


@cl.on_chat_start
async def start():
    cl.user_session.set("holmes_history", [])
    cl.user_session.set("attachments", [])
    label = "Mock development mode" if settings.adapter == "mock" else "HolmesGPT"
    note = "" if adapter.incremental else " This backend returns the final answer at completion; token streaming is unavailable."
    await cl.Message(content=f"{label}. Upload files or start an investigation.{note}").send()


@cl.on_chat_resume
async def resume(thread):
    state = await layer.load_context(thread["id"]) if layer else {"history": [], "attachments": []}
    cl.user_session.set("holmes_history", state["history"])
    cl.user_session.set("attachments", state["attachments"])
    log.info("conversation_resumed")


class ChainlitUI:
    def __init__(self):
        self.answer = cl.Message(content="")
        self.step = cl.Step(name="Investigation activity", type="tool", show_input=False)

    @property
    def content(self):
        return self.answer.content

    async def start(self):
        await self.step.send()
        await self.answer.send()

    async def token(self, text):
        await self.answer.stream_token(text)

    async def whole(self, text):
        self.answer.content = text
        await self.answer.update()

    async def progress(self, text):
        # Render public operational text literally, not as links/HTML from tools.
        self.step.output = text
        self.step.language = "text"
        await self.step.update()

    async def finish(self, status):
        self.step.output = status
        await self.step.update()
        await self.answer.update()


async def persist_state():
    if layer:
        await layer.save_context(cl.context.session.thread_id,
            cl.user_session.get("holmes_history", []), cl.user_session.get("attachments", []))


@cl.on_message
async def message(message: cl.Message):
    sid = cl.user_session.get("id")
    if sid in active or len(active) >= settings.max_active:
        await cl.Message(content="An investigation is already running or the server is busy. Please retry.").send()
        return
    active[sid] = asyncio.current_task()
    request_id = uuid.uuid4().hex
    log_context = request_context.set(request_id)
    ui = ChainlitUI()
    status = "Investigation interrupted"
    log.info("investigation_started request=%s", request_id)
    stage = "ui_start"
    try:
        await asyncio.wait_for(ui.start(), settings.ui_timeout)
        stage = "uploads"
        attachments = list(cl.user_session.get("attachments", []))
        if len(message.elements) > settings.max_files or len(attachments) + len(message.elements) > settings.max_uploads:
            raise ValueError("Too many attachments")
        if len(message.content.encode()) > settings.max_history_bytes:
            raise ValueError("Prompt exceeds configured limit")
        if message.elements and settings.adapter != "mock" and settings.attachment_mode == "disabled":
            raise ValueError("Attachment path mapping must be configured before uploads")
        for element in message.elements:
            if not element.path:
                raise ValueError("Only uploaded local files are supported")
            attachments.append(await save_upload(element.path, element.name, settings))
        cl.user_session.set("attachments", attachments)
        stage = "persist_uploads"
        if layer:
            await layer.create_step(message.to_dict())
        await persist_state()
        history = cl.user_session.get("holmes_history", [])
        if len(json.dumps(history).encode()) > settings.max_history_bytes:
            raise ValueError("Conversation context limit reached; start a new chat")
        if not client:
            raise RuntimeError("Service is not ready")
        stage = "holmes_stream"
        new_history = await stream_to_ui(client.events(message.content, history, attachments), ui, settings)
        if len(json.dumps(new_history).encode()) > settings.max_history_bytes:
            raise ValueError("Returned context exceeds configured limit; start a new chat")
        if layer:
            stage = "persist_completed_turn"
            ui.answer.streaming = False
            await layer.update_step(ui.answer.to_dict())
            await layer.save_context(cl.context.session.thread_id, new_history, attachments)
        cl.user_session.set("holmes_history", new_history)
        status = "Investigation completed"
        log.info("investigation_completed request=%s", request_id)
    except asyncio.CancelledError:
        log.info("investigation_cancelled request=%s", request_id)
        ui.answer.content += "\n\n[Interrupted — this answer may be incomplete.]"
        raise
    except Exception as exc:
        log.error("investigation_failed request=%s stage=%s type=%s", request_id, stage, type(exc).__name__)
        ui.answer.content += f"\n\n[Investigation failed or was interrupted. Reference: {request_id}. Check service logs and configuration.]"
    finally:
        try:
            await asyncio.wait_for(ui.finish(status), settings.ui_timeout)
        except (Exception, asyncio.CancelledError) as exc:
            log.warning("ui_finalization_failed request=%s type=%s", request_id, type(exc).__name__)
        active.pop(sid, None)
        request_context.reset(log_context)


async def cancel_current():
    task = active.get(cl.user_session.get("id"))
    if task and task is not asyncio.current_task():
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@cl.on_stop
async def stop():
    await cancel_current()


@cl.on_chat_end
async def end():
    await cancel_current()
