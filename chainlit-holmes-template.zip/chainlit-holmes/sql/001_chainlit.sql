-- Run only with search_path set to the NEW, dedicated schema. Never public/Open WebUI.
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, identifier TEXT UNIQUE NOT NULL, "createdAt" TEXT, metadata JSONB NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS threads (
 id TEXT PRIMARY KEY, "createdAt" TEXT, name TEXT, "userId" TEXT REFERENCES users(id),
 "userIdentifier" TEXT, tags TEXT[], metadata JSONB NOT NULL DEFAULT '{}'
);
-- Opaque backend messages can contain tool context/reasoning. Never return this
-- table through Chainlit's thread API or copy it into frontend-visible metadata.
CREATE TABLE IF NOT EXISTS holmes_context (
 "threadId" TEXT PRIMARY KEY REFERENCES threads(id) ON DELETE CASCADE,
 history JSONB NOT NULL DEFAULT '[]', attachments JSONB NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS steps (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, "threadId" TEXT REFERENCES threads(id) ON DELETE CASCADE,
 "parentId" TEXT, command TEXT, modes JSONB, streaming BOOLEAN, "waitForAnswer" BOOLEAN, "isError" BOOLEAN,
 metadata JSONB DEFAULT '{}', tags TEXT[], input TEXT, output TEXT, "createdAt" TEXT, start TEXT, "end" TEXT,
 generation JSONB, "showInput" TEXT, "defaultOpen" BOOLEAN, "autoCollapse" BOOLEAN, language TEXT, icon TEXT
);
CREATE TABLE IF NOT EXISTS feedbacks (
 id TEXT PRIMARY KEY, "forId" TEXT NOT NULL, "threadId" TEXT REFERENCES threads(id) ON DELETE CASCADE,
 value INTEGER NOT NULL, comment TEXT
);
CREATE TABLE IF NOT EXISTS elements (
 id TEXT PRIMARY KEY, "threadId" TEXT REFERENCES threads(id) ON DELETE CASCADE, type TEXT, "chainlitKey" TEXT,
 url TEXT, "objectKey" TEXT, name TEXT, display TEXT, size TEXT, language TEXT, page INTEGER,
 "autoPlay" BOOLEAN, "playerConfig" JSONB, "forId" TEXT, mime TEXT, props JSONB
);
CREATE INDEX IF NOT EXISTS threads_user ON threads ("userId");
CREATE INDEX IF NOT EXISTS steps_thread_created ON steps ("threadId", "createdAt");
CREATE INDEX IF NOT EXISTS elements_thread ON elements ("threadId");
